(function () {
  'use strict';

  const PLUGIN_ID = 'steamnexus';
  if (typeof Millennium === 'undefined') return;

  let currentApp = null;
  let busy = false;

  /* ========== Lucide SVG Icons (inline) ========== */
  const ICONS = {
    plus:       `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    trash:      `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>`,
    refresh:    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>`,
    wrench:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,
    check:      `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    alertTri:   `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
    key:        `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.78 7.78 5.5 5.5 0 0 1 7.78-7.78zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>`,
    x:          `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    download:   `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    search:     `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
    loader:     `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>`,
    zap:        `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
    shield:     `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
    server:     `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>`,
    ban:        `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>`,
    wifi:       `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="20" x2="22" y2="20"/><path d="M8.5 16a4.6 4.6 0 0 1 7 0"/><path d="M5 12.5a9.1 9.1 0 0 1 14 0"/><path d="M1.5 9a13.5 13.5 0 0 1 21 0"/></svg>`,
  };

  /* ========== Error Messages ========== */
  const ERROR_MESSAGES = {
    // Add/Remove errors
    no_license:       'No posees la licencia de este juego. Cómpralo primero en Steam.',
    no_ownership:     'No se detectó la propiedad del juego en tu cuenta de Steam.',
    already_added:    'Este juego ya está agregado a Steam Nexus.',
    already_removed:  'Este juego ya fue eliminado de Steam Nexus.',
    lua_not_found:    'No se encontró el archivo Lua necesario para este juego.',
    lua_write_fail:   'No se pudo escribir el archivo Lua. Verifica los permisos de la carpeta.',
    lua_delete_fail:  'No se pudo eliminar el archivo Lua. Puede estar en uso.',
    download_fail:    'Error al descargar los archivos del juego. Verifica tu conexión.',
    server_offline:   'El servidor de Steam Nexus no está disponible. Intenta más tarde.',
    rate_limited:     'Demasiadas solicitudes. Espera unos segundos e intenta de nuevo.',
    unauthorized:     'Tu licencia de Steam Nexus expiró o fue revocada.',
    game_not_supported: 'Este juego no es compatible con Steam Nexus.',
    steam_running:    'Steam necesita reiniciarse para aplicar los cambios.',
    disk_full:        'No hay espacio suficiente en disco para completar la operación.',
    permission_denied:'Permisos insuficientes. Ejecuta Steam como administrador.',
    
    // Fix errors
    fix_download_fail:    'No se pudo descargar la fix. Verifica tu conexión a internet.',
    fix_extract_fail:     'Error al extraer la fix. El archivo puede estar corrupto.',
    fix_apply_fail:       'No se pudo aplicar la fix. Los archivos del juego pueden estar en uso.',
    fix_not_compatible:   'Esta fix no es compatible con tu versión del juego.',
    fix_already_applied:  'Esta fix ya fue aplicada anteriormente.',
    fix_requires_game:    'Necesitas tener el juego agregado a Nexus antes de aplicar fixes.',
    
    // Activation errors  
    key_invalid:      'La clave ingresada no es válida. Verifica que esté bien escrita.',
    key_expired:      'Esta clave de activación ha expirado.',
    key_already_used: 'Esta clave ya fue utilizada en otra cuenta.',
    key_revoked:      'Esta clave fue revocada. Contacta al soporte.',
    key_limit:        'Se alcanzó el límite de activaciones para esta clave.',
    hwid_mismatch:    'Esta clave está vinculada a otro equipo.',
    
    // Generic fallbacks
    unknown:          'Ocurrió un error inesperado. Intenta de nuevo.',
    connection:       'No se pudo conectar con el servidor. Verifica tu conexión a internet.',
    timeout:          'La operación tardó demasiado. Intenta de nuevo.',
  };

  /**
   * Resolves an error response into a user-friendly message.
   * Checks res.reason, res.error, and res.code against the ERROR_MESSAGES map.
   * Falls back to a provided default or the generic 'unknown' message.
   */
  function resolveError(res, fallback) {
    if (!res) return fallback || ERROR_MESSAGES.connection;
    
    // If the backend returned an error code that maps to our messages
    if (res.code && ERROR_MESSAGES[res.code]) return ERROR_MESSAGES[res.code];
    
    // If backend sent a human-readable reason
    if (res.reason && typeof res.reason === 'string') return res.reason;
    
    // If backend sent an error string
    if (res.error && typeof res.error === 'string') {
      // Try to match known error patterns in the error string
      const errLower = res.error.toLowerCase();
      if (errLower.includes('license') || errLower.includes('licencia') || errLower.includes('ownership'))
        return ERROR_MESSAGES.no_license;
      if (errLower.includes('connect') || errLower.includes('conexi'))
        return ERROR_MESSAGES.connection;
      if (errLower.includes('timeout') || errLower.includes('timed out'))
        return ERROR_MESSAGES.timeout;
      if (errLower.includes('permission') || errLower.includes('permiso') || errLower.includes('access denied'))
        return ERROR_MESSAGES.permission_denied;
      if (errLower.includes('rate') || errLower.includes('limit') || errLower.includes('too many'))
        return ERROR_MESSAGES.rate_limited;
      if (errLower.includes('disk') || errLower.includes('space') || errLower.includes('espacio'))
        return ERROR_MESSAGES.disk_full;
      if (errLower.includes('expired') || errLower.includes('expirad'))
        return ERROR_MESSAGES.key_expired;
      if (errLower.includes('revoke') || errLower.includes('revocad'))
        return ERROR_MESSAGES.key_revoked;
      if (errLower.includes('hwid') || errLower.includes('hardware'))
        return ERROR_MESSAGES.hwid_mismatch;
      if (errLower.includes('already') && errLower.includes('used'))
        return ERROR_MESSAGES.key_already_used;
      if (errLower.includes('not supported') || errLower.includes('no soportado') || errLower.includes('no compatible'))
        return ERROR_MESSAGES.game_not_supported;
      if (errLower.includes('extract') || errLower.includes('extraer') || errLower.includes('corrupt'))
        return ERROR_MESSAGES.fix_extract_fail;
      
      // Return the raw error if no pattern matched
      return res.error;
    }
    
    return fallback || ERROR_MESSAGES.unknown;
  }

  /* ========== Comunicación con Python ========== */
  async function callPlugin(method, args = {}) {
    try {
      const res = await Millennium.callServerMethod(PLUGIN_ID, method, args);
      return typeof res === 'string' ? JSON.parse(res) : res;
    } catch (e) { return { success: false, error: e.message, code: 'connection' }; }
  }

  /* ========== Notificaciones Toast ========== */
  function toast(text, ok = true) {
    const el = document.createElement('div');
    el.className = 'sn-toast';
    el.innerHTML = `
      <span class="sn-toast-icon">${ok ? ICONS.check : ICONS.x}</span>
      <span class="sn-toast-text">${text}</span>
    `;
    el.classList.add(ok ? 'sn-toast-ok' : 'sn-toast-err');
    document.body.appendChild(el);

    requestAnimationFrame(() => el.classList.add('sn-toast-show'));

    setTimeout(() => {
      el.classList.remove('sn-toast-show');
      el.classList.add('sn-toast-hide');
      setTimeout(() => el.remove(), 450);
    }, ok ? 3500 : 5000); // Errors stay longer so user can read
  }

  /* ========== Estilos ========== */
  (function injectCSS() {
    if (document.getElementById('steamnexus-style')) return;
    const s = document.createElement('style');
    s.id = 'steamnexus-style';
    s.textContent = `
      :root {
        --sn-accent: #4ba3e3;
        --sn-accent-glow: rgba(75, 163, 227, 0.35);
        --sn-danger: #e05555;
        --sn-danger-glow: rgba(224, 85, 85, 0.35);
        --sn-success: #48c78e;
        --sn-success-glow: rgba(72, 199, 142, 0.35);
        --sn-warn: #f0c040;
        --sn-surface: rgba(18, 24, 36, 0.92);
        --sn-surface-raised: rgba(30, 42, 62, 0.65);
        --sn-surface-hover: rgba(40, 58, 85, 0.70);
        --sn-border: rgba(75, 163, 227, 0.18);
        --sn-border-focus: rgba(75, 163, 227, 0.50);
        --sn-text: #dce3ec;
        --sn-text-muted: #8b98a8;
        --sn-radius-sm: 8px;
        --sn-radius-md: 12px;
        --sn-radius-lg: 16px;
        --sn-radius-pill: 100px;
        --sn-shadow-sm: 0 2px 8px rgba(0,0,0,0.25);
        --sn-shadow-md: 0 8px 30px rgba(0,0,0,0.40);
        --sn-shadow-lg: 0 16px 50px rgba(0,0,0,0.55);
        --sn-ease: cubic-bezier(0.16, 1, 0.3, 1);
      }

      @keyframes sn-spin { to { transform: rotate(360deg); } }
      @keyframes sn-ping {
        0%  { box-shadow: 0 0 0 0 rgba(224, 85, 85, 0.5); }
        70% { box-shadow: 0 0 0 8px rgba(224, 85, 85, 0); }
        100%{ box-shadow: 0 0 0 0 rgba(224, 85, 85, 0); }
      }
      @keyframes sn-shimmer {
        0%   { background-position: -200% 0; }
        100% { background-position: 200% 0; }
      }
      @keyframes sn-slide-up {
        from { opacity: 0; transform: translateY(8px); }
        to   { opacity: 1; transform: translateY(0); }
      }

      .sn-toast {
        position: fixed; bottom: 40px; left: 50%;
        transform: translateX(-50%) translateY(18px) scale(0.96);
        display: flex; align-items: center; gap: 10px;
        padding: 11px 22px; border-radius: var(--sn-radius-pill);
        font-family: "Motiva Sans", system-ui, sans-serif;
        font-size: 12.5px; font-weight: 600;
        color: #fff; z-index: 9999999;
        backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
        box-shadow: var(--sn-shadow-md);
        border: 1px solid rgba(255,255,255,0.08);
        opacity: 0; pointer-events: none;
        transition: all 0.4s var(--sn-ease);
        max-width: 480px;
      }
      .sn-toast-ok  { background: linear-gradient(135deg, rgba(72,199,142,0.88), rgba(56,160,110,0.92)); }
      .sn-toast-err { background: linear-gradient(135deg, rgba(224,85,85,0.88), rgba(180,60,60,0.92)); }
      .sn-toast-show { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
      .sn-toast-hide { opacity: 0; transform: translateX(-50%) translateY(-12px) scale(0.96); }
      .sn-toast-icon { display: flex; align-items: center; flex-shrink: 0; }
      .sn-toast-text { white-space: nowrap; letter-spacing: 0.2px; overflow: hidden; text-overflow: ellipsis; }

      .sn-btn {
        font-family: "Motiva Sans", system-ui, sans-serif;
        text-transform: uppercase; font-weight: 700;
        font-size: 10.5px; letter-spacing: 0.8px;
        cursor: pointer; transition: all 0.25s var(--sn-ease);
        border: none; text-decoration: none !important;
        display: inline-flex; align-items: center; justify-content: center;
        gap: 6px; outline: none; position: relative; overflow: hidden;
      }
      .sn-btn::after {
        content: ''; position: absolute; inset: 0;
        background: linear-gradient(rgba(255,255,255,0.10), transparent);
        opacity: 0; transition: opacity 0.2s;
      }
      .sn-btn:hover::after { opacity: 1; }
      .sn-btn:hover { transform: translateY(-1px); }
      .sn-btn:active { transform: translateY(1px) scale(0.98); }
      .sn-btn:disabled { opacity: 0.5; pointer-events: none; }
      .sn-btn svg { flex-shrink: 0; }

      .sn-btn-main {
        height: 34px; padding: 0 22px; border-radius: var(--sn-radius-pill);
        background: linear-gradient(135deg, var(--sn-accent), #2f7cb8);
        color: #fff; margin-left: 10px; vertical-align: middle;
        box-shadow: 0 3px 14px rgba(75,163,227,0.25);
      }
      .sn-btn-main:hover { box-shadow: 0 5px 22px var(--sn-accent-glow); }
      .sn-btn-main.is-remove {
        background: linear-gradient(135deg, var(--sn-danger), #b83c3c);
        box-shadow: 0 3px 14px rgba(224,85,85,0.25);
      }
      .sn-btn-main.is-remove:hover { box-shadow: 0 5px 22px var(--sn-danger-glow); }
      .sn-btn-main.is-restart {
        background: linear-gradient(135deg, var(--sn-warn), #d4a520);
        color: #1a1a2e; box-shadow: 0 3px 14px rgba(240,192,64,0.25);
      }
      .sn-btn-main.is-restart:hover { box-shadow: 0 5px 22px rgba(240,192,64,0.4); }

      .sn-btn-spinner svg { animation: sn-spin 0.8s linear infinite; }

      .sn-chip {
        display: inline-flex !important; vertical-align: top !important;
        margin-right: 6px !important; margin-bottom: 6px !important;
        padding: 0 14px !important; height: 28px !important;
        border-radius: var(--sn-radius-pill) !important;
        font-size: 10px !important;
        box-shadow: var(--sn-shadow-sm);
        backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
        border: 1px solid rgba(255,255,255,0.06);
      }
      .sn-chip-danger {
        background: linear-gradient(135deg, rgba(224,85,85,0.75), rgba(180,60,60,0.80)) !important;
        color: #fff !important; animation: sn-ping 2.5s infinite;
      }
      .sn-chip-success {
        background: linear-gradient(135deg, rgba(72,199,142,0.70), rgba(56,160,110,0.75)) !important;
        color: #fff !important;
      }
      .sn-chip-neutral {
        background: linear-gradient(135deg, rgba(45,60,80,0.80), rgba(35,50,70,0.85)) !important;
        color: var(--sn-text) !important;
      }

      .sn-overlay {
        position: fixed; inset: 0; background: rgba(0,0,0,0.78);
        z-index: 999999; display: flex; align-items: center; justify-content: center;
        backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
        opacity: 0; transition: opacity 0.35s var(--sn-ease);
      }
      .sn-overlay.show { opacity: 1; }

      .sn-panel {
        background: var(--sn-surface); border-radius: var(--sn-radius-lg);
        padding: 28px; color: var(--sn-text);
        border: 1px solid var(--sn-border); box-shadow: var(--sn-shadow-lg);
        backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px);
        transform: scale(0.92) translateY(12px);
        transition: transform 0.35s var(--sn-ease);
        position: relative; overflow: hidden;
      }
      .sn-overlay.show .sn-panel { transform: scale(1) translateY(0); }
      .sn-panel::before {
        content: ''; position: absolute; top: 0; left: 20%; right: 20%; height: 1px;
        background: linear-gradient(90deg, transparent, var(--sn-accent), transparent);
        opacity: 0.45;
      }

      .sn-panel-header { display: flex; align-items: center; gap: 10px; margin-bottom: 22px; }
      .sn-panel-header-icon {
        width: 36px; height: 36px;
        display: flex; align-items: center; justify-content: center;
        border-radius: var(--sn-radius-sm);
        background: rgba(75,163,227,0.12); color: var(--sn-accent);
      }
      .sn-panel-header-icon svg { width: 18px; height: 18px; }
      .sn-panel-title {
        font-family: "Motiva Sans", system-ui, sans-serif;
        font-size: 16px; font-weight: 700;
        color: #fff; margin: 0; letter-spacing: 0.2px;
      }

      .sn-input {
        width: 100%; padding: 10px 14px 10px 38px;
        border-radius: var(--sn-radius-sm);
        border: 1px solid var(--sn-border);
        background: rgba(10,14,22,0.6);
        color: #fff; font-size: 13px;
        font-family: "Motiva Sans", system-ui, sans-serif;
        outline: none; box-sizing: border-box;
        transition: border-color 0.2s, box-shadow 0.2s;
      }
      .sn-input:focus { border-color: var(--sn-border-focus); box-shadow: 0 0 0 3px rgba(75,163,227,0.10); }
      .sn-input::placeholder { color: var(--sn-text-muted); }
      .sn-input-wrap { position: relative; margin-bottom: 16px; }
      .sn-input-wrap .sn-input-icon {
        position: absolute; left: 12px; top: 50%; transform: translateY(-50%);
        color: var(--sn-text-muted); display: flex; pointer-events: none;
      }

      .sn-fix-list { max-height: 280px; overflow-y: auto; padding-right: 4px; }
      .sn-fix-list::-webkit-scrollbar { width: 4px; }
      .sn-fix-list::-webkit-scrollbar-track { background: transparent; }
      .sn-fix-list::-webkit-scrollbar-thumb { background: rgba(75,163,227,0.25); border-radius: 4px; }
      .sn-fix-item {
        background: var(--sn-surface-raised);
        padding: 12px 14px; border-radius: var(--sn-radius-sm);
        margin-bottom: 8px;
        display: flex; justify-content: space-between; align-items: center;
        border: 1px solid transparent; transition: all 0.2s;
        animation: sn-slide-up 0.3s ease-out both;
      }
      .sn-fix-item:hover { background: var(--sn-surface-hover); border-color: var(--sn-border); }
      .sn-fix-item-name {
        font-size: 12px; font-weight: 500; color: var(--sn-text);
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 320px;
      }

      .sn-btn-install {
        height: 28px; padding: 0 14px; border-radius: var(--sn-radius-pill);
        background: linear-gradient(135deg, var(--sn-accent), #2f7cb8);
        color: #fff; font-size: 10px;
        box-shadow: 0 2px 8px rgba(75,163,227,0.2);
        flex-shrink: 0; margin-left: 10px;
      }
      .sn-btn-install:hover { box-shadow: 0 4px 14px var(--sn-accent-glow); }
      .sn-btn-install.done { background: linear-gradient(135deg, var(--sn-success), #36a070); pointer-events: none; }
      .sn-btn-install.spin svg { animation: sn-spin 0.8s linear infinite; }

      .sn-panel-footer { display: flex; justify-content: flex-end; margin-top: 22px; gap: 10px; }

      .sn-btn-close {
        height: 34px; padding: 0 18px; border-radius: var(--sn-radius-pill);
        background: var(--sn-surface-raised); color: var(--sn-text-muted);
        border: 1px solid rgba(255,255,255,0.06); font-size: 10.5px;
      }
      .sn-btn-close:hover { color: #fff; background: var(--sn-surface-hover); }

      .sn-reason-list {
        background: rgba(30,42,62,0.5);
        padding: 16px 20px; margin: 18px 0;
        border-radius: var(--sn-radius-md);
        font-size: 12px; line-height: 1.8; color: var(--sn-text);
        border-left: 3px solid var(--sn-accent);
      }
      .sn-reason-list.playable  { border-left-color: var(--sn-success); }
      .sn-reason-list.unplayable { border-left-color: var(--sn-danger); }

      .sn-activation-panel { width: 380px; }
      .sn-activation-panel .sn-input {
        padding-left: 40px;
        font-family: "JetBrains Mono", "Fira Code", monospace;
        text-align: center; letter-spacing: 1px;
      }
      .sn-status-msg {
        font-size: 11.5px; font-weight: 600;
        min-height: 18px; margin-bottom: 14px; text-align: center;
        transition: color 0.3s;
        display: flex; align-items: center; justify-content: center; gap: 6px;
      }

      .sn-error-detail {
        background: rgba(224, 85, 85, 0.08);
        border: 1px solid rgba(224, 85, 85, 0.20);
        border-radius: var(--sn-radius-sm);
        padding: 10px 14px; margin-top: 10px;
        font-size: 11px; color: var(--sn-danger);
        line-height: 1.5; display: flex; align-items: flex-start; gap: 8px;
      }
      .sn-error-detail svg { flex-shrink: 0; margin-top: 1px; }

      .sn-skeleton {
        height: 46px; border-radius: var(--sn-radius-sm);
        background: linear-gradient(90deg, var(--sn-surface-raised), rgba(45,62,90,0.5), var(--sn-surface-raised));
        background-size: 200% 100%;
        animation: sn-shimmer 1.5s ease-in-out infinite;
        margin-bottom: 8px;
      }

      .sn-empty { text-align: center; padding: 30px 20px; color: var(--sn-text-muted); font-size: 12px; }
      .sn-empty-err { color: var(--sn-danger); }
    `;
    document.head.appendChild(s);
  })();

  /* ========== Helpers ========== */
  function createOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'sn-overlay';
    document.body.appendChild(overlay);
    requestAnimationFrame(() => requestAnimationFrame(() => overlay.classList.add('show')));
    return overlay;
  }

  function closeOverlay(overlay) {
    overlay.classList.remove('show');
    setTimeout(() => overlay.remove(), 380);
  }

  /* ========== Menú de Fixes ========== */
  async function openFixMenu(appid, name) {
    const overlay = createOverlay();
    const panel = document.createElement('div');
    panel.className = 'sn-panel';
    panel.style.width = '520px';
    panel.innerHTML = `
      <div class="sn-panel-header">
        <div class="sn-panel-header-icon">${ICONS.wrench}</div>
        <h3 class="sn-panel-title">Fixes para ${name}</h3>
      </div>
      <div class="sn-input-wrap">
        <span class="sn-input-icon">${ICONS.search}</span>
        <input type="text" class="sn-input" id="sn-fix-search" placeholder="Buscar un fix...">
      </div>
      <div class="sn-fix-list" id="sn-fix-content">
        <div class="sn-skeleton"></div><div class="sn-skeleton"></div><div class="sn-skeleton"></div>
      </div>
      <div class="sn-panel-footer">
        <button class="sn-btn sn-btn-close" id="sn-fix-close">${ICONS.x}<span>Cerrar</span></button>
      </div>
    `;
    overlay.appendChild(panel);

    const searchInput = panel.querySelector('#sn-fix-search');
    const content = panel.querySelector('#sn-fix-content');
    panel.querySelector('#sn-fix-close').onclick = () => closeOverlay(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeOverlay(overlay); });

    try {
      const data = await callPlugin('checkAvailableFixes', { appid });
      if (data && data.success) {
        const render = (filter = '') => {
          content.innerHTML = '';
          const fixesToRender = data.fixes
            ? data.fixes.filter(f => decodeURIComponent(f.filename).toLowerCase().includes(filter.toLowerCase()))
            : [];

          if (fixesToRender.length === 0) {
            content.innerHTML = filter
              ? `<div class="sn-empty">Ningún fix coincide con "${filter}"</div>`
              : `<div class="sn-empty">No hay fixes disponibles para este juego.</div>`;
            return;
          }

          fixesToRender.forEach((f, i) => {
            const item = document.createElement('div');
            item.className = 'sn-fix-item';
            item.style.animationDelay = `${i * 0.04}s`;
            const fname = decodeURIComponent(f.filename.split('/').pop().replace('.zip', ''));
            item.innerHTML = `<span class="sn-fix-item-name" title="${fname}">${fname}</span>`;

            const btn = document.createElement('button');
            btn.className = 'sn-btn sn-btn-install';
            btn.innerHTML = `${ICONS.download}<span>Instalar</span>`;
            btn.onclick = async () => {
              btn.disabled = true;
              btn.classList.add('spin');
              btn.innerHTML = `${ICONS.loader}<span>...</span>`;
              const r = await callPlugin('downloadAndInstallFix', { appid, filename: f.filename });
              btn.classList.remove('spin');
              if (r && r.success) {
                btn.classList.add('done');
                btn.innerHTML = `${ICONS.check}<span>Listo</span>`;
                toast('Fix aplicada correctamente', true);
              } else {
                btn.disabled = false;
                btn.innerHTML = `${ICONS.refresh}<span>Reintentar</span>`;
                const errMsg = resolveError(r, ERROR_MESSAGES.fix_apply_fail);
                toast(errMsg, false);
                // Show inline error detail under the item
                const existingErr = item.querySelector('.sn-error-detail');
                if (existingErr) existingErr.remove();
                const errDetail = document.createElement('div');
                errDetail.className = 'sn-error-detail';
                errDetail.innerHTML = `${ICONS.alertTri}<span>${errMsg}</span>`;
                item.style.flexWrap = 'wrap';
                item.appendChild(errDetail);
              }
            };
            item.appendChild(btn);
            content.appendChild(item);
          });
        };
        searchInput.oninput = (e) => render(e.target.value);
        render('');
      } else {
        const errMsg = resolveError(data, 'No se pudieron cargar los fixes del servidor.');
        content.innerHTML = `
          <div class="sn-empty sn-empty-err">
            <div style="margin-bottom:6px;">${ICONS.wifi}</div>
            <div>${errMsg}</div>
          </div>`;
      }
    } catch (err) {
      content.innerHTML = `
        <div class="sn-empty sn-empty-err">
          <div style="margin-bottom:6px;">${ICONS.wifi}</div>
          <div>${ERROR_MESSAGES.connection}</div>
        </div>`;
    }
  }

  /* ========== Menú de Info del Juego ========== */
  async function openGameInfo(appid, name) {
    const data = await callPlugin('getGameInfo', { appid });
    const isPlayable = data && data.playable;
    const overlay = createOverlay();
    const panel = document.createElement('div');
    panel.className = 'sn-panel';
    panel.style.width = '480px';
    panel.style.borderColor = isPlayable ? 'rgba(72,199,142,0.30)' : 'rgba(224,85,85,0.30)';

    const headerIconBg = isPlayable ? 'rgba(72,199,142,0.12)' : 'rgba(224,85,85,0.12)';
    const headerIconColor = isPlayable ? 'var(--sn-success)' : 'var(--sn-danger)';
    const headerIcon = isPlayable ? ICONS.shield : ICONS.alertTri;

    panel.innerHTML = `
      <div class="sn-panel-header">
        <div class="sn-panel-header-icon" style="background:${headerIconBg}; color:${headerIconColor};">${headerIcon}</div>
        <h3 class="sn-panel-title">${name}</h3>
      </div>
      <div class="sn-reason-list ${isPlayable ? 'playable' : 'unplayable'}">
        ${data.reasons && data.reasons.length > 0
          ? data.reasons.map(r => `<div>• ${r}</div>`).join('')
          : isPlayable
            ? '<div>El juego funciona correctamente con Steam Nexus.</div>'
            : '<div>Este juego no es compatible. Puede requerir una fix o no estar soportado aún.</div>'
        }
      </div>
      <div class="sn-panel-footer">
        <button class="sn-btn sn-btn-close" id="sn-info-close">${ICONS.x}<span>Cerrar</span></button>
      </div>
    `;
    overlay.appendChild(panel);
    panel.querySelector('#sn-info-close').onclick = () => closeOverlay(overlay);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeOverlay(overlay); });
  }

  /* ========== Modal de Activación ========== */
  async function ensureActivated() {
    const data = await callPlugin('isActivated');
    if (data && data.success && data.activated !== false) return true;

    return new Promise(resolve => {
      const overlay = createOverlay();
      const panel = document.createElement('div');
      panel.className = 'sn-panel sn-activation-panel';
      panel.innerHTML = `
        <div class="sn-panel-header">
          <div class="sn-panel-header-icon">${ICONS.key}</div>
          <h3 class="sn-panel-title">Activar Steam Nexus</h3>
        </div>
        <div class="sn-input-wrap">
          <span class="sn-input-icon" style="color: var(--sn-accent);">${ICONS.key}</span>
          <input type="text" class="sn-input" id="sn-key-in" placeholder="XXXX-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false">
        </div>
        <div class="sn-status-msg" id="sn-status"></div>
        <div class="sn-panel-footer">
          <button class="sn-btn sn-btn-close" id="sn-can-btn">${ICONS.x}<span>Cancelar</span></button>
          <button class="sn-btn sn-btn-main" id="sn-act-btn">${ICONS.zap}<span>Activar</span></button>
        </div>
      `;
      overlay.appendChild(panel);

      const statusMsg = panel.querySelector('#sn-status');
      const keyInput = panel.querySelector('#sn-key-in');
      const actBtn = panel.querySelector('#sn-act-btn');

      panel.querySelector('#sn-can-btn').onclick = () => { closeOverlay(overlay); resolve(false); };

      keyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') actBtn.click(); });

      actBtn.onclick = async () => {
        const key = keyInput.value.trim();
        if (!key) {
          statusMsg.style.color = 'var(--sn-warn)';
          statusMsg.innerHTML = `${ICONS.alertTri} Ingresa una clave de activación`;
          keyInput.focus();
          return;
        }

        actBtn.disabled = true;
        actBtn.innerHTML = `<span class="sn-btn-spinner">${ICONS.loader}</span><span>Validando...</span>`;
        statusMsg.style.color = 'var(--sn-accent)';
        statusMsg.innerHTML = `${ICONS.server} Conectando con el servidor...`;

        const r = await callPlugin('activate', { key: key });

        if (r && r.success) {
          statusMsg.style.color = 'var(--sn-success)';
          statusMsg.innerHTML = `${ICONS.check} Steam Nexus activado correctamente`;
          setTimeout(() => { closeOverlay(overlay); resolve(true); }, 1200);
        } else {
          const errMsg = resolveError(r, ERROR_MESSAGES.key_invalid);
          statusMsg.style.color = 'var(--sn-danger)';
          statusMsg.innerHTML = `${ICONS.ban} ${errMsg}`;
          actBtn.disabled = false;
          actBtn.innerHTML = `${ICONS.zap}<span>Activar</span>`;
          keyInput.focus();
          keyInput.select();
        }
      };

      setTimeout(() => keyInput.focus(), 400);
    });
  }

  /* ========== Inicialización Principal ========== */
  async function init() {
    const appid = location.href.match(/\/app\/(\d+)/)?.[1];
    if (!appid) return;
    if (document.getElementById(`sn-main-btn-${appid}`)) return;

    const purchaseRow = document.querySelector('.game_purchase_action');
    const sideContainer = document.querySelector('.apphub_OtherSiteInfo');
    if (!purchaseRow || !sideContainer) return;

    document.querySelectorAll('[id^="sn-"]').forEach(el => el.remove());

    currentApp = appid;
    const name = document.querySelector('.apphub_AppName')?.textContent?.trim() || 'Juego';

    try {
      const status = await callPlugin('hasLuaForApp', { appid });
      const info = await callPlugin('getGameInfo', { appid });

      // Botón principal (Añadir/Eliminar)
      if (!document.getElementById(`sn-main-btn-${appid}`)) {
        const btnAdd = document.createElement('button');
        btnAdd.id = `sn-main-btn-${appid}`;
        btnAdd.className = `sn-btn sn-btn-main ${status && status.has_lua ? 'is-remove' : ''}`;
        btnAdd.innerHTML = status && status.has_lua
          ? `${ICONS.trash}<span>Eliminar</span>`
          : `${ICONS.plus}<span>Añadir Juego</span>`;

        btnAdd.onclick = async (e) => {
          e.preventDefault();
          if (busy) return;
          busy = true;

          if (await ensureActivated()) {
            const isRemoving = btnAdd.classList.contains('is-remove');
            btnAdd.disabled = true;
            btnAdd.innerHTML = `<span class="sn-btn-spinner">${ICONS.loader}</span><span>${isRemoving ? 'Eliminando...' : 'Agregando...'}</span>`;
            
            const res = await callPlugin(isRemoving ? 'removeViaNexus' : 'addViaNexus', { appid });

            if (res && res.success) {
              toast(
                isRemoving ? `${name} eliminado de Steam Nexus` : `${name} agregado a Steam Nexus`,
                !isRemoving
              );
              btnAdd.disabled = false;
              btnAdd.className = 'sn-btn sn-btn-main is-restart';
              btnAdd.innerHTML = `${ICONS.refresh}<span>Reiniciar</span>`;
              btnAdd.onclick = () => callPlugin('restartSteam');
            } else {
              const errMsg = resolveError(res, isRemoving
                ? 'No se pudo eliminar el juego. Los archivos pueden estar en uso.'
                : ERROR_MESSAGES.no_license
              );
              toast(errMsg, false);
              btnAdd.disabled = false;
              btnAdd.innerHTML = isRemoving
                ? `${ICONS.trash}<span>Eliminar</span>`
                : `${ICONS.plus}<span>Añadir Juego</span>`;
            }
          }
          busy = false;
        };
        purchaseRow.appendChild(btnAdd);
      }

      // Botón de Info (Jugable/No Jugable) en barra lateral
      if (!document.getElementById(`sn-info-${appid}`)) {
        const iBtn = document.createElement('a');
        iBtn.id = `sn-info-${appid}`;
        iBtn.className = `sn-btn sn-chip ${info && info.playable ? 'sn-chip-success' : 'sn-chip-danger'}`;
        iBtn.innerHTML = info && info.playable
          ? `${ICONS.check}<span>JUGABLE</span>`
          : `${ICONS.alertTri}<span>NO JUGABLE</span>`;
        iBtn.onclick = (e) => { e.preventDefault(); openGameInfo(appid, name); };
        sideContainer.insertBefore(iBtn, sideContainer.firstChild);
      }

      // Botón de FIXES en barra lateral
      if (!document.getElementById(`sn-fix-${appid}`)) {
        const fBtn = document.createElement('a');
        fBtn.id = `sn-fix-${appid}`;
        fBtn.className = 'sn-btn sn-chip sn-chip-neutral';
        fBtn.innerHTML = `${ICONS.wrench}<span>FIXES</span>`;
        fBtn.onclick = (e) => { e.preventDefault(); openFixMenu(appid, name); };
        sideContainer.insertBefore(fBtn, sideContainer.firstChild);
      }
    } catch (e) {
      console.error('Nexus Error en Init:', e);
    }
  }

  // Observador para detectar cuando Steam cambia de página de tienda
  let timer;
  const uiObserver = new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const appid = location.href.match(/\/app\/(\d+)/)?.[1];
      if (appid && (appid !== currentApp || !document.getElementById(`sn-main-btn-${appid}`))) {
        init();
      }
    }, 400);
  });

  uiObserver.observe(document.body, { childList: true, subtree: true });
  init();
})();